Môn học: Công nghệ web và ứng dụng
Lớp: SE346.G12
Đề tài: Website quảng bá du lịch và đặt tour
Nhóm: 7
Thành viên:
- Nguyễn Thanh Anh Tuyên, 12520492
- Trần Minh Luận, 12520248
- Trần Như Luận, 12520249